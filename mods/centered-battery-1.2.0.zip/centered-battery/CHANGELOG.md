# 1.2.0

- Cápsula temática de 74 × 36: misma altura que los widgets vecinos, sin sombra.
- Dibujo de 56,6 × 26; cuerpo de 54 × 26 con contorno uniforme de 1,5.
- Núcleo de 46 × 18, aproximadamente el 82% de la altura interior.
- Proporción horizontal adaptada a la referencia enviada; terminal pequeña y centrada.
- Conserva lógica de batería, colores, tooltip, clics, popup, perfiles y animaciones.
- Captura real, pruebas de estados y rollback oficial a 1.1.0.

# 1.1.0

- Silueta de 33,6 × 16 en lugar de 30 × 14, manteniendo el espacio original de la barra.
- Menor padding y núcleo de 24 × 10,5, con el mismo porcentaje continuo y turquesa.
- Contorno normal un 6% más claro, con grosor intacto; terminal de 3,6 × 7.
- Popup, tooltip, perfiles, lecturas y animaciones sin cambios funcionales.
- Comparación antes/después y validación de rollback, desactivación y perfiles.
