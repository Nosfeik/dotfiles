# 1.1.0

- Silueta de 33,6 × 16 en lugar de 30 × 14, manteniendo el espacio original de la barra.
- Menor padding y núcleo de 24 × 10,5, con el mismo porcentaje continuo y turquesa.
- Contorno normal un 6% más claro, con grosor intacto; terminal de 3,6 × 7.
- Popup, tooltip, perfiles, lecturas y animaciones sin cambios funcionales.
- Comparación antes/después y validación de rollback, desactivación y perfiles.
